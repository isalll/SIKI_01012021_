package com.siki.android;

public class Keyword {

	private String text;
	private String number;

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}
public void getColor(){

}
}
