package com.siki.android;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TabHost;
import android.widget.TabHost.TabContentFactory;
import android.widget.TabHost.TabSpec;
import android.widget.TabWidget;
import android.widget.TextView;
import android.widget.Toast;


import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import com.siki.library.JSONParser;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

//import com.example.android.fragments.ArticleFragment;
//import com.example.android.fragments.ArticleFragment;
//import com.example.android.fragments.ArticleFragment;
//import android.app.FragmentTransaction;
//import org.achartengine.chartdemo.demo.GeneratedChartDemo;
//import org.achartengine.chartdemo.demo.GeneratedChartDemo;
//import org.achartengine.chartdemo.demo.chart.PieChartBuilder;
//import org.achartengine.chartdemo.demo.chart.XYChartBuilder;
//import org.achartengine.chartdemo.demo.chart.XYChartBuilder;


@SuppressLint("NewApi")
public class Dashboard_coorporateActivity extends Fragment {
	JSONArray grapik = null;

	private static final String AR_JUDUL = "kode";
	private static final String AR_NAMA = "name";
	private static final String AR_URAIAN = "uraian";
	private static final String AR_SEKTOR = "sektor";
	private static final String AR_SUB = "subsektor";

	public static final int FRAGMENT_DASHBOARD = 0;
	public static final int FRAGMENT_NEWS = 1;
	public static final int FRAGMENT_FINDHS = 2;
	public static final int FRAGMENT_ABOUT = 3;
	public static final int FRAGMENT_PERUSAHAAN = 4;
	
	private ProgressWheel prog_one, prog_two, prog_three, prog_four;
	private TextView tv_prog_one, tv_prog_two, tv_prog_three, tv_prog_four, tv_title;
	private TextView tv_prog_one_lblup,tv_prog_one_lbldown,tv_prog_two_lblup,tv_prog_two_lbldown,tv_prog_three_lblup,tv_prog_three_lbldown,tv_prog_four_lbldown;
	
	private TabHost mTabHost;
	private ListView lvKeyword;
	private KeywordAdapter adapterKeyword;
	private ArrayList<Keyword> listKeyword;
	private ArrayList<Keyword> listHSKeyword;
	
	TabWidget tabWidget;
	public static final int FRAGMENT_CHARTHS = 4;

	

			  private String[] mMenuText;

		  private String[] mMenuSummary;
		  //private String[] listHS;
	
	
	
	StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();

	ArrayList<String> list_eksdown,list_eksup,list_impdown,list_impup,listHSArrayString,listUraianHSArrayString = new ArrayList<String>(); ;
	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		super.onCreateView(inflater, container, savedInstanceState);

		final View v = inflater.inflate(R.layout.activity_dashboardcoorporate, container, false);

	   	StrictMode.setThreadPolicy(policy);

		setupTabHost(v);

		setupTab(new TextView(getActivity()), "Impor Up");
		setupTab(new TextView(getActivity()), "Impor Down");
		setupTab(new TextView(getActivity()), "Ekspor Up");
		setupTab(new TextView(getActivity()), "Ekspor Down");
		
		mTabHost.setCurrentTab(0);	    
		reLoadTable(v,Globals.url_dsb_impup);

		init(v);
		return v;
	}


	private void init(View v) {
       
         tv_title = (TextView) v.findViewById(R.id.tv_title);
         tv_title.setText("Dashboard Perusahaan");
       
        
	}
    private void setupTabHost(View v) {
		mTabHost = (TabHost) v.findViewById(android.R.id.tabhost);
		mTabHost.setup();
	}

	private void setupTab(final View view, final String tag) {
		View tabview = createTabView(mTabHost.getContext(), tag);

		TabSpec setContent = mTabHost.newTabSpec(tag).setIndicator(tabview)
				.setContent(new TabContentFactory() {
					public View createTabContent(String tag) {
						return view;
					}
				});
		mTabHost.addTab(setContent);
	}

	public void switchTab(int tab){
		mTabHost.setCurrentTab(tab);
}

	private static View createTabView(final Context context, final String text) {
		View view = LayoutInflater.from(context)
				.inflate(R.layout.tabs_bg, null);
		TextView tv = (TextView) view.findViewById(R.id.tabsText);
		tv.setText(text);
		return view;
	}

	public void reLoadTable(View v, String url) {

    String result = null;
   	InputStream is = null;
   	
   	try{
   	        HttpClient httpclient = new DefaultHttpClient();
   	        HttpPost httppost = new HttpPost(url);
   	        HttpResponse response = httpclient.execute(httppost); 
   	        HttpEntity entity = response.getEntity();
   	        is = entity.getContent();

   	        Log.e("log_tag", "connection success ");
   	        Toast.makeText(getActivity(), "pass", Toast.LENGTH_SHORT).show();
   	}
   	catch(Exception e)
   	{
   	        Log.e("log_tag", "Error in http connection "+e.toString());
   	       Toast.makeText(getActivity(), "Connection fail", Toast.LENGTH_SHORT).show();

   	}

	//convert response to string
	try
	{
	        BufferedReader reader = new BufferedReader(new InputStreamReader(is,"iso-8859-1"),8);
	        StringBuilder sb = new StringBuilder();
	        String line = null;
	        while ((line = reader.readLine()) != null) 
	        {
	                sb.append(line + "\n");
	                Toast.makeText(getActivity(), "Input Reading pass", Toast.LENGTH_SHORT).show();
	        }
	        is.close();

	        result=sb.toString();
	}
	catch(Exception e)
	{
	       Log.e("log_tag", "Error converting result "+e.toString());
	    Toast.makeText(getActivity(), " Input reading fail", Toast.LENGTH_SHORT).show();

	}

		//parse json data

		try
	{

		JSONArray jArray = new JSONArray(result);

	//String re=jArray.getString(jArray.length()-1);
	
	//----------- List utk chart --------------
 
	
//-----------------------------
  
	lvKeyword = (ListView) v.findViewById(R.id.lvDashboard);

	listKeyword = new ArrayList<Keyword>();
	listHSKeyword = new ArrayList<Keyword>();
	listHSArrayString = new ArrayList<String>();
	listUraianHSArrayString = new ArrayList<String>();


	prog_one = (ProgressWheel) v.findViewById(R.id.prog_one);
	prog_two = (ProgressWheel) v.findViewById(R.id.prog_two);
	prog_three = (ProgressWheel) v.findViewById(R.id.prog_three);
		prog_four = (ProgressWheel) v.findViewById(R.id.prog_four);


    tv_prog_one = (TextView) v.findViewById(R.id.tv_prog_one);
    tv_prog_two = (TextView) v.findViewById(R.id.tv_prog_two);
    tv_prog_three = (TextView) v.findViewById(R.id.tv_prog_three);
	tv_prog_four = (TextView) v.findViewById(R.id.tv_prog_four);

    tv_prog_one_lbldown = (TextView) v.findViewById(R.id.textView3);

    tv_prog_two_lbldown = (TextView) v.findViewById(R.id.textView5);

    tv_prog_three_lbldown = (TextView) v.findViewById(R.id.textView7);

	tv_prog_four_lbldown = (TextView) v.findViewById(R.id.textView8);


   
	int flag=1;

		//for(int i=1;i<=1;i++){
			JSONParser jParser = new JSONParser();
			JSONObject json = jParser.AmbilJson(Globals.url_graph_perusahaan+"?kode="+Globals.id+"&&kondisi=data1");
			//JSONObject json = jParser.AmbilJson("http://192.168.137.1/iris/php/graph_perusahaan.php?kode=320");
			//JSONObject json = jParser.AmbilJson(Globals.url_graph+"?kon=graph1");
			try{
				grapik = json.getJSONArray("dash");
				JSONObject ad = grapik.getJSONObject(0);

		//		if (i==1){
					prog_one.setProgress((int)(100)); 	// Set progress 50%
					tv_prog_one.setText(ad.getInt(AR_JUDUL)+"");				// Set value 50 for TextView
					tv_prog_one_lbldown.setText(ad.getString(AR_NAMA)+"");

		//		}

			}catch (JSONException e){
				e.printStackTrace();
			}
		//}
	}
	catch(JSONException e)
	{
	        Log.e("log_tag", "Error parsing data "+e.toString());
	        Toast.makeText(getActivity(), "JsonArray fail", Toast.LENGTH_SHORT).show();
	}
		
	
	}

	private Keyword addKeyword(String text) {
		Keyword keyword = new Keyword();
		keyword.setText(text);
		//keyword.setText(text);
		return keyword;
	}

	public void setNewPage(Fragment fragment, int pageIndex) {
/*
        final FragmentManager fm = getFragmentManager();
        while (fm.getBackStackEntryCount() > 0) {
            fm.popBackStackImmediate();
        }
*/
    	 
		getFragmentManager().beginTransaction()

				.replace(R.id.fragment_dashboard, fragment, "currentFragment")
				.commit();
		
		//FragmentManager.popBackStack(String name, FragmentManager.POP_BACK_STACK_INCLUSIVE);
	}

	public void onNews(View v) {
   		setNewPage(new LonjakanActivity(), FRAGMENT_NEWS);
	}
	
	public void onFindHS(View v) {
    	setNewPage(new VisitorActivity(), FRAGMENT_FINDHS);
    }
	public void onAbout(View v) {
		setNewPage(new AboutActivity(), FRAGMENT_ABOUT);
	}
	
	public void onPerusahaan(View v) {
		//masih error........ test lagi script: doInBackground
		setNewPage(new PerusahaanActivity(), FRAGMENT_PERUSAHAAN);
	}

}
